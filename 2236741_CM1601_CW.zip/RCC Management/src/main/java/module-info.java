module com.example.rcc_management {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.rcc_management to javafx.fxml;
    exports com.example.rcc_management;
}