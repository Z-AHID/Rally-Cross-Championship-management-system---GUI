package com.example.rcc_management;

//class for load function table view
public class load {
    private String loadname;
    private int loadage;
    private String loadteam;
    private String loadcar;
    private int loadpoints;

    public load(String loadname, String loadage, String loadteam, String loadcar, String loadpoints) {
        this.loadname = loadname;
        this.loadage = Integer.parseInt(loadage);
        this.loadteam = loadteam;
        this.loadcar = loadcar;
        this.loadpoints = Integer.parseInt(loadpoints);
    }

    public String getLoadname() {
        return loadname;
    }

    public int getLoadage() {
        return loadage;
    }

    public String getLoadteam() {
        return loadteam;
    }

    public String getLoadcar() {
        return loadcar;
    }

    public int getLoadpoints() {
        return loadpoints;
    }
}
