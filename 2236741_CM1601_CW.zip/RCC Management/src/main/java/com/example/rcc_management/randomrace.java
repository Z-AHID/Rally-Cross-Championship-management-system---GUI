package com.example.rcc_management;

// class for random race generation function table view
public class randomrace {
    private int randomposition;
    private String randomname;
    private int randompoints;

    public randomrace(String randomposition, String randomname, String randompoints) {
        this.randomposition = Integer.parseInt(randomposition);
        this.randomname = randomname;
        this.randompoints = Integer.parseInt(randompoints);
    }

    public int getRandomposition() {
        return randomposition;
    }

    public String getRandomname() {
        return randomname;
    }

    public int getRandompoints() {
        return randompoints;
    }
}
