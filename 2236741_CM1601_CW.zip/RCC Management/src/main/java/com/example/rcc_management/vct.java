package com.example.rcc_management;

// class for VCT table view
public class vct {
    private String zname;
    private int zage;
    private String zteam;
    private String zcar;
    private int zpoints;

    public vct(String zname, int zage, String zteam, String zcar, int zpoints) {
        this.zname = zname;
        this.zage = zage;
        this.zteam = zteam;
        this.zcar = zcar;
        this.zpoints = zpoints;
    }

    public String getZname() {
        return zname;
    }

    public int getZage() {
        return zage;
    }

    public String getZteam() {
        return zteam;
    }

    public String getZcar() {
        return zcar;
    }

    public int getZpoints() {
        return zpoints;
    }

}
