package com.example.rcc_management;

// class for displaying all races function table view
public class displayrrace {
    private String racedate;
    private String  racelocation;
    private int  raceposition;
    private String  racedriver;

    private int racepoints;

    public displayrrace(String racedate, String racelocation, String raceposition, String racedriver, String racepoints) {
        this.racedate = racedate;
        this.racelocation = racelocation;
        this.raceposition = Integer.parseInt(raceposition);
        this.racedriver = racedriver;
        this.racepoints = Integer.parseInt(racepoints);
    }

  public String getRacedate() {
        return racedate;
    }

    public String getRacelocation() {
        return racelocation;
    }

    public int getRaceposition() {
        return raceposition;
    }

    public String getRacedriver() {
        return racedriver;
    }

    public int getRacepoints() {
        return racepoints;
    }
}
