package com.example.rcc_management;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.io.*;
import java.util.Optional;

// add, delete, update functions
public class functions {

    // Function to add a driver
    void addDriver(String name, int age, String team, String car, int points){

        try {
            // reading file
            FileWriter driver = new FileWriter("C:\\Users\\User\\IdeaProjects\\RCC Management\\driver_details.txt", true);
            BufferedWriter driver_records = new BufferedWriter(driver);
            //writing records into text file
            driver_records.write(name + " " + age + " " + team + " " + car + " " + points + "\n");
            driver_records.close();
            // prompt shown to user after successfully adding a driver
            Alert driveradded = new Alert(Alert.AlertType.INFORMATION);
            driveradded.setTitle("Add driver record");
            driveradded.setContentText("Driver record has been successfully added");
            Optional<ButtonType> result = driveradded.showAndWait();
        }
        catch (Exception e) {return;}

    }

    // Function to delete a driver
    void deleteDriver(String name){

        try {
            // opening the driver details file and reading lines
            File file = new File("C:\\Users\\User\\IdeaProjects\\RCC Management\\driver_details.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            StringBuilder content = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                String[] x = line.split(" ");
                if (!name.equals(x[0])) {
                    content.append(line).append("\n");
                }
            }
            reader.close();

            // opening file in write mode and writing the records back except the record of the user entered driver name
            FileWriter writer = new FileWriter(file);
            writer.write(content.toString());
            writer.close();
            // prompt shown to user after successful deletion
            Alert driverdelete = new Alert(Alert.AlertType.INFORMATION);
            driverdelete.setTitle("Delete drive record");
            driverdelete.setContentText("Driver record has been deleted successfully");
            Optional<ButtonType> result = driverdelete.showAndWait();

        }
        catch (IOException e) {}

    }

    //getting the driver name and reading lines and deleting the drive record before updating
    void updateGetDriver(String name){

        try {
            // opening the target file and reading lines
            File driverFile = new File("C:\\Users\\User\\IdeaProjects\\RCC Management\\driver_details.txt");
            BufferedReader reader = new BufferedReader(new FileReader(driverFile));
            String line;
            StringBuilder content = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                String[] x = line.split(" ");
                if (!name.equals(x[0])) {
                    content.append(line).append("\n");
                }
            }
            reader.close();

            // opening file in write mode and writing the records back except the record of the user entered driver name
            FileWriter writer = new FileWriter(driverFile);
            writer.write(content.toString());
            writer.close();

        } catch (IOException e) {}
    }

    // updating driver details
    void updateDriver(String updatedName, int updatedAge, String updatedTeam,String updatedCar,int updatedPoints){
        try {
            //re entering all the driver details to update
            FileWriter driverFile = new FileWriter("C:\\Users\\User\\IdeaProjects\\RCC Management\\driver_details.txt", true);
            BufferedWriter driver_records = new BufferedWriter(driverFile);
            driver_records.write(updatedName + " " + updatedAge + " " + updatedTeam + " " + updatedCar + " " + updatedPoints + "\n");
            driver_records.close();
            //prompt shown to user after successfully updating
            Alert driverupdated = new Alert(Alert.AlertType.INFORMATION);
            driverupdated.setTitle("Update driver record");
            driverupdated.setContentText("Driver record has been successfully updated");
            Optional<ButtonType> result = driverupdated.showAndWait();
        } catch (Exception e) {
            return;
        }
    }
}
