package com.example.rcc_management;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.*;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class HelloController {

    @FXML
    private Label vlabel;
    @FXML
    private TextField name;

    @FXML
    private TextField age;

    @FXML
    private TextField team;

    @FXML
    private TextField car;

    @FXML
    private TextField points;

    @FXML
    private TextField updated_name;
    @FXML
    private TextField updated_age;
    @FXML
    private TextField updated_team;
    @FXML
    private TextField updated_car;
    @FXML
    private TextField updated_points;

    @FXML
    private TableColumn<vct, Integer> zage;

    @FXML
    private TableColumn<vct, String> zcar;

    @FXML
    private TableColumn<vct, String> zname;

    @FXML
    private TableColumn<vct, Integer> zpoints;

    @FXML
    private TableView<vct> ztable;

    @FXML
    private TableColumn<vct, String> zteam;

    @FXML
    private TableColumn<randomrace, String> randomname;

    @FXML
    private TableColumn<randomrace, Integer> randompoints;

    @FXML
    private TableColumn<randomrace, Integer> randomposition;

    @FXML
    private Label datelabel;

    @FXML
    private Label locationlabel;

    @FXML
    private TableView<randomrace> randomracetable;

    @FXML
    private TableView<displayrrace> allraces;

    @FXML
    private TableColumn<displayrrace, String> racedate;

    @FXML
    private TableColumn<displayrrace, String> racedriver;

    @FXML
    private TableColumn<displayrrace, String> racelocation;

    @FXML
    private TableColumn<displayrrace, Integer> racepoints;

    @FXML
    private TableColumn<displayrrace, Integer> raceposition;

    @FXML
    private TableColumn<load, Integer> loadage;

    @FXML
    private TableColumn<load, String> loadcar;

    @FXML
    private TableView<load> loadingtable;

    @FXML
    private TableColumn<load, String> loadname;

    @FXML
    private TableColumn<load, Integer> loadpoints;

    @FXML
    private TableColumn<load, String> loadteam;

    @FXML
    private Label loadlabel;

    @FXML
    private Label uplabel;


    // main menu functions
    // when the add driver button is clicked the add driver interface is loaded
    public void adding_driver() throws IOException {
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("add-driver.fxml"));
        primaryStage.setTitle("Add a Driver");
        primaryStage.setScene(new Scene(root, 250, 500));
        primaryStage.show();
    }

    // when the delete driver button is clicked the delete driver interface is loaded
    public void deleting_driver() throws IOException {
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("delete-driver.fxml"));
        primaryStage.setTitle("Delete driver record");
        primaryStage.setScene(new Scene(root, 330, 250));
        primaryStage.show();
    }

    // when the update driver button is clicked the update driver interface is loaded
    public void updating_driver() throws IOException {
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("update-driver.fxml"));
        primaryStage.setTitle("Update driver record");
        primaryStage.setScene(new Scene(root, 670, 550));
        primaryStage.show();
    }

    // when the sorted view of driver data  button is clicked the interface is loaded
    public void leaderboard_table() throws IOException {
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("table.fxml"));
        primaryStage.setTitle("Leaderboard");
        primaryStage.setScene(new Scene(root, 620, 520));
        primaryStage.show();
    }

    // when the stimulate random race button is clicked the interface is loaded
    public void random_race_generation() throws IOException {
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("randomrace.fxml"));
        primaryStage.setTitle("Leaderboard");
        primaryStage.setScene(new Scene(root, 620, 520));
        primaryStage.show();
    }

    // when the display all race button is clicked the interface is loaded
    public void display_all_race() throws IOException {
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("randomraceshow.fxml"));
        primaryStage.setTitle("Leaderboard");
        primaryStage.setScene(new Scene(root, 610, 610));
        primaryStage.show();
    }

    // when the load file button is clicked the  interface is loaded
    public void loadtable() throws IOException {
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("loadtable.fxml"));
        primaryStage.setTitle("Leaderboard");
        primaryStage.setScene(new Scene(root, 620, 520));
        primaryStage.show();
    }



    // other functions
    //add driver
    public void add_driver_function() {
        String d_name = name.getText();

        // validating age input
        String drv_age = age.getText();
        int d_age = 0;
        try {
            d_age = Integer.parseInt(drv_age);

        } catch (NumberFormatException e) {
            vlabel.setText("Invalid Entry");

        }

        String d_team = team.getText();
        String d_car = car.getText();

        //validating points input

        String drv_points = points.getText();
        int d_points = 0;
        try {
            d_points = Integer.parseInt(drv_points);

        } catch (NumberFormatException e) {
            vlabel.setText("Invalid Entry");
        }


        // if the label is displaying invalid entry user cant add data until closing and reopening the window
        if (vlabel.getText().equals("Invalid Entry")){
            Alert wrongvalue = new Alert(Alert.AlertType.ERROR);
            wrongvalue.setTitle("Invalid Entry");
            wrongvalue.setHeaderText("Couldn't Add Record !");
            wrongvalue.setContentText("Please Enter only numeric values to Age or Points"+"\n"+"\n"+"CLOSE AND REOPEN WINDOW BEFORE TRYING AGAIN");
            wrongvalue.showAndWait();
        }
        else
        {
            functions x = new functions();
            x.addDriver(d_name, d_age, d_team, d_car, d_points);
        }
    }

    //delete driver details
    public void delete_driver_function() {
        String driverName = name.getText();
        boolean found = false;

        try {
            File driverFile = new File("driver_details.txt");
            Scanner findRecord = new Scanner(driverFile);
            while (findRecord.hasNextLine()) {
                String data = findRecord.nextLine();
                if (data.contains(driverName)) {
                    found = true;
                    break;
                }
            }
            findRecord.close();
        }
        catch (FileNotFoundException e) {}

        //if driver name is found in the text file the function works if not a prompt is displayed to the user
        if (found) {
            functions x = new functions();
            x.deleteDriver(driverName);
        }
        else {
            Alert errorMessage = new Alert(Alert.AlertType.INFORMATION);
            errorMessage.setTitle("Deletion Error");
            errorMessage.setHeaderText("Couldn't Delete Record");
            errorMessage.setContentText("Driver not found please check and enter again");
            errorMessage.showAndWait();
        }
    }

    //update driver details
    public void update_driver_function() {

        // deleting the driver record
        String driverName = name.getText();
        boolean found = false;
        try {
            File driverFile = new File("driver_details.txt");
            Scanner driverCheck = new Scanner(driverFile);
            while (driverCheck.hasNextLine()) {
                String driverNameCheck = driverCheck.nextLine();
                if (driverNameCheck.contains(driverName)) {
                    found = true;
                    break;
                }
            }
            driverCheck.close();
        }
        catch (FileNotFoundException e) {}

        //if driver name is found in the text file the function works if not a prompt is displayed to the user
        if (found) {
            String updated_d_name = updated_name.getText();
            String updated_d_team = updated_team.getText();
            String updated_d_car = updated_car.getText();

            String updated_d_age = updated_age.getText();
            int uDAge = 0;
            // validating age input
            try {
                uDAge = Integer.parseInt(updated_d_age);

            } catch (NumberFormatException e) {
                uplabel.setText("Invalid Entry");
            }


            String updated_d_points = updated_points.getText();
            int uDPoints = 0;

            try {
                uDPoints = Integer.parseInt(updated_d_points);

            } catch (NumberFormatException e) {
                uplabel.setText("Invalid Entry");
            }
            // if the label is displaying invalid entry user cant add data until closing and reopening the window
            if (uplabel.getText().equals("Invalid Entry")){
                Alert wrongvalue = new Alert(Alert.AlertType.INFORMATION);
                wrongvalue.setTitle("Invalid Entry");
                wrongvalue.setHeaderText("Couldn't Add Record !");
                wrongvalue.setContentText("Please Enter only numeric values to Age or Points"+"\n"+"\n"+"CLOSE AND REOPEN WINDOW BEFORE TRYING AGAIN");
                wrongvalue.showAndWait();
            }
            else
            {
                functions x = new functions();
                x.updateGetDriver(driverName);
                x.updateDriver(updated_d_name, uDAge, updated_d_team, updated_d_car, uDPoints);
            }
        }

        else
        {
            Alert errorMessage = new Alert(Alert.AlertType.INFORMATION);
            errorMessage.setTitle("Update Error");
            errorMessage.setHeaderText("Couldn't Update Record");
            errorMessage.setContentText("Driver not found please check and enter again");
            errorMessage.showAndWait();
        }
    }

    // used to display champions standing order
    public void dis() throws IOException {
        // opening a file in read mode to read the lines in that file
        BufferedReader driverFile = new BufferedReader(new FileReader("driver_details.txt"));
        List<String> lines = new ArrayList<>();
        String line = driverFile.readLine();
        while (line != null) {
            lines.add(line);
            line = driverFile.readLine();
        }
        driverFile.close();

        // two lists are implemented to append the score and driver details
        List<Integer> score = new ArrayList<>();
        List<String[]> driverList = new ArrayList<>();
        for (String x : lines) {
            String[] lined = x.split(" ");
            score.add(Integer.parseInt(lined[4]));
            driverList.add(lined);
        }

        // manually sorting the score which was appended for the score list
        for (int i = 0; i < score.size(); i++) {
            for (int j = i + 1; j < score.size(); j++) {
                if (score.get(i) < score.get(j)) {
                    int tempScore = score.get(i);
                    score.set(i, score.get(j));
                    score.set(j, tempScore);

                    String[] tempDriver = driverList.get(i);
                    driverList.set(i, driverList.get(j));
                    driverList.set(j, tempDriver);
                }
            }
        }

        // implemeting a new list to store the sorted data
        List<String[]> sortedDriverList = new ArrayList<>();

        // appending the above list to get sorted data in descending oreder
        for (int y : score) {
            for (String[] x : driverList) {
                if (Integer.parseInt(x[4]) == y) {
                    sortedDriverList.add(x);
                }
            }
        }

        // opening a file and writing the sorted data list into it
        FileWriter vctfile = new FileWriter("vctsortedfile.txt");
        for (String[] k : sortedDriverList) {
            vctfile.write(String.join(" ", k) + "\n");
        }
        vctfile.close();

        ObservableList<vct> tableData = FXCollections.observableArrayList();


    // opening a file in read mode to read the lines in the sorted file
        BufferedReader file2 = new BufferedReader(new FileReader("vctsortedfile.txt"));
        String line2 = file2.readLine();
        while (line2 != null) {
            String[] sorteddata = line2.split(" ");
            // create a new User object and add it to the observable array list
            tableData.add(new vct(sorteddata[0], Integer.parseInt(sorteddata[1]), sorteddata[2], sorteddata[3], Integer.parseInt(sorteddata[4])));
            line2 = file2.readLine();
        }
        file2.close();

    // setting up the columns in table view
        zname.setCellValueFactory(new PropertyValueFactory<vct, String>("zname"));
        zage.setCellValueFactory(new PropertyValueFactory<vct, Integer>("zage"));
        zteam.setCellValueFactory(new PropertyValueFactory<vct, String>("zteam"));
        zcar.setCellValueFactory(new PropertyValueFactory<vct, String>("zcar"));
        zpoints.setCellValueFactory(new PropertyValueFactory<vct, Integer>("zpoints"));

    // adding data into the table view
        ztable.setItems(tableData);


    }

    // stimulating race
    public void randomdis() throws IOException {
        // generating a random date
        Random randomGeneration = new Random();
        int day = randomGeneration.nextInt(25) + 1;
        int month = randomGeneration.nextInt(12) + 1;
        int year = randomGeneration.nextInt(2) + 2023;
        LocalDate date = LocalDate.of(year, month, day);
        String raceDate = date.toString();

        // generating a random location out of given locations
        List<String> locations = Arrays.asList("Nyirad", "Holjes", "Montalegre", "Barcelona", "Riga", "Norway");
        String raceLocation = locations.get(randomGeneration.nextInt(locations.size()));

        // opening the file which contains driver details to read driver names
        List<String> driverFile = Files.readAllLines(Paths.get("driver_details.txt"));
        FileWriter raceFile = new FileWriter("racefile.txt", true);

        // name list implemented to store the driver names
        List<String> nameList = new ArrayList<>();
        // reading and retrieving driver name from champion standing order file to be passed to a list
        for (String line : driverFile) {
            String[] getName = line.split(" ");
            String driverName = getName[0];
            nameList.add(driverName);
        }

        // position list and points list implemented to store the position and points in a list
        List<Integer> positionList = new ArrayList<>();
        List<Integer> pointsList = new ArrayList<>();
        // using while loop to generate position for the user and points depending on the position
        int count = 1;
        while (count <= driverFile.size()) {
            positionList.add(count);
            if (count == 1) {
                pointsList.add(10);
            } else if (count == 2) {
                pointsList.add(7);
            } else if (count == 3) {
                pointsList.add(5);
            } else {
                pointsList.add(0);
            }
            count++;
        }

        // shuffling the driver names
        Collections.shuffle(nameList);

        // implementing a new list to store race data
        List<List<Object>> raceDataList = new ArrayList<>();
        // using z variable to increase the index values of the elements inside the new list
        int z = 0;
        while (z < driverFile.size()) {
            List<Object> j = new ArrayList<>();
            j.add(positionList.get(z));
            j.add(nameList.get(z));
            j.add(pointsList.get(z));
            raceDataList.add(j);
            z++;
        }

        // writing data into observable list to add data to table view
        ObservableList<randomrace> raceData = FXCollections.observableArrayList();
        for (List<Object> list : raceDataList) {
            String position = list.get(0).toString();
            String name = list.get(1).toString();
            String points = list.get(2).toString();
            raceFile.write(raceLocation+" "+raceDate+" "+position+" "+name+" "+points+"\n");
            raceData.add(new randomrace(position,name,points));
        }

        raceFile.close();


        //table view column setup
        randomname.setCellValueFactory(new PropertyValueFactory<randomrace,String>("randomname"));
        randomposition.setCellValueFactory(new PropertyValueFactory<randomrace,Integer>("randomposition"));
        randompoints.setCellValueFactory(new PropertyValueFactory<randomrace,Integer>("randompoints"));

        randomracetable.setItems(raceData);
        datelabel.setText(raceDate);
        locationlabel.setText(raceLocation);

    }

    //displaying all races to the user
    public void allrandom() throws IOException  {

        ObservableList<displayrrace> data = FXCollections.observableArrayList();

        //reading race file
        BufferedReader raceFile = new BufferedReader(new FileReader("racefile.txt."));
        String line2 = raceFile.readLine();
        while (line2 != null) {
            String[] j = line2.split(" ");
            // create a new User object and add it to the observable array list
            data.add(new displayrrace(j[0],j[1],j[2],j[3],j[4]));
            line2 = raceFile.readLine();
        }
        raceFile.close();

        //table view column setup
        racedate.setCellValueFactory(new PropertyValueFactory<displayrrace,String>("racedate"));
        racelocation.setCellValueFactory(new PropertyValueFactory<displayrrace,String>("racelocation"));
        raceposition.setCellValueFactory(new PropertyValueFactory<displayrrace,Integer>("raceposition"));
        racedriver.setCellValueFactory(new PropertyValueFactory<displayrrace,String>("racedriver"));
        racepoints.setCellValueFactory(new PropertyValueFactory<displayrrace,Integer>("racepoints"));

        allraces.setItems(data);

    }

    // saving file
    public void save_function() throws IOException {
        FileInputStream loadfile = new FileInputStream("driver_details.txt");
        FileOutputStream savefile = new FileOutputStream("savefile.txt");

        // reading the files in drive details file and writing it to= save file
        int i;
        while((i=loadfile.read())!=-1){
            savefile.write((char)i);
        }
        loadfile.close();
        savefile.close();
        // prompt shown to the user
        Alert savedtotextfile = new Alert(Alert.AlertType.INFORMATION);
        savedtotextfile.setContentText("Data has been saved to a text file");
        savedtotextfile.showAndWait();
    }

    // loading text file
    public void load_function() throws IOException {
        ObservableList<load> data = FXCollections.observableArrayList();

        // reading and displaying data from save file
        BufferedReader saveFile = new BufferedReader(new FileReader("savefile.txt"));
        String saveFileLines = saveFile.readLine();
        while (saveFileLines != null) {
            String[] x = saveFileLines.split(" ");
            data.add(new load(x[0],x[1],x[2],x[3],x[4]));
            saveFileLines = saveFile.readLine();
        }
        saveFile.close();

        //table view column setup
        loadname.setCellValueFactory(new PropertyValueFactory<load,String>("loadname"));
        loadage.setCellValueFactory(new PropertyValueFactory<load,Integer>("loadage"));
        loadteam.setCellValueFactory(new PropertyValueFactory<load,String>("loadteam"));
        loadcar.setCellValueFactory(new PropertyValueFactory<load,String>("loadcar"));
        loadpoints.setCellValueFactory(new PropertyValueFactory<load,Integer>("loadpoints"));

        loadingtable.setItems(data);
        String j = "Use the main menu to edit the above details";
        loadlabel.setText(j);

    }

    //exiting the program
    public void exit_function() {
        //confirmation prompt from user asking whether to quit the program or not
        Alert exit = new Alert(Alert.AlertType.CONFIRMATION);
        exit.setTitle("Quit Program");
        exit.setContentText("Are you sure you want to quit");

        if (exit.showAndWait().get() == ButtonType.OK) {
            System.out.println("SYSTEM CLOSED");
            System.exit(0);
        }

    }
}